package synthese.projet.filterapp;

import android.content.Context;
import android.view.TextureView;

public class MainView extends TextureView {
    MainRenderer mRenderer;

    MainView ( Context context ) {
        super ( context );
        mRenderer = new MainRenderer(context, this);

        this.setSurfaceTextureListener(mRenderer);
        /*setEGLContextClientVersion ( 2 );
        setRenderer ( mRenderer );
        setRenderMode ( GLSurfaceView.RENDERMODE_WHEN_DIRTY );*/
    }

    /*public void surfaceCreated ( SurfaceHolder holder ) {
        super.surfaceCreated ( holder );
    }

    public void surfaceDestroyed ( SurfaceHolder holder ) {
        super.surfaceDestroyed ( holder );
    }

    public void surfaceChanged ( SurfaceHolder holder, int format, int w, int h ) {
        super.surfaceChanged ( holder, format, w, h );
    }*/

    public void onResume() {
        mRenderer.onResume();
    }

    public void onPause() {
        mRenderer.onPause();
    }

    public void setFilter (int filterId) {
        mRenderer.selectFilter(filterId);
    }
}
